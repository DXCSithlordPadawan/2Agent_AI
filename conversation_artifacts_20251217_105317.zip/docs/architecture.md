
# Architecture (Air‑Gap ArgoCD LXC Delivery)

Generated: 2025-12-17 10:53:17 UTC

## Context
This design delivers Argo CD into an air‑gapped **Proxmox VE 9.1** cluster via LXC containers, with **k3s** providing a lightweight Kubernetes control plane and **Gitea** serving as the internal Git server. Proxmox defaults are **storage=local-lvm** and **bridge=vmbr0**.

Key platform notes:
- Proxmox VE 9.1 introduces **OCI-based LXC templates** (tech preview for app containers); we standardize on **system LXC (Debian 13)** for k3s/Gitea. [Press release](https://www.proxmox.com/en/about/company-details/press-releases/proxmox-virtual-environment-9-1), [Feature overview](https://4sysops.com/archives/proxmox-ve-91-create-lxc-containers-from-oci-images-granular-nested-virt-cpu-control-and-more/)
- Raspberry Pi OS **Trixie (Debian 13)** provides modern base packages for staging and packaging. [Raspberry Pi blog](https://www.raspberrypi.com/news/trixie-the-new-version-of-raspberry-pi-os/)

## Mermaid: Physical View
```mermaid
flowchart LR
    PI[Pi (Trixie, ARM64)] --> USB[USB/SSD Transfer]
    USB --> PVE[Proxmox VE 9.1 Cluster]
    subgraph PVE[Proxmox VE 9.1]
      subgraph LXC_1[ LXC: argocd-k3s (Debian 13) ]
        K3S[k3s Server]
        ACD[Argo CD]
        K3S --> ACD
      end
      subgraph LXC_2[ LXC: gitea (Debian 13) ]
        Gitea[(Gitea Git Server)]
      end
      subgraph REG[ Local Registry (optional) ]
        Registry[(registry.internal:5000)]
      end
      ACD --- Gitea
      K3S --- Registry
    end
```

## Mermaid: Data Flow
```mermaid
sequenceDiagram
  autonumber
  participant Pi as Raspberry Pi (Trixie)
  participant Media as USB/SSD
  participant Proxmox as Proxmox VE 9.1
  participant LXC1 as LXC argocd-k3s
  participant LXC2 as LXC gitea
  Pi->>Pi: Mirror images & build signed bundle
  Pi->>Media: Write airgap-bundle + SHA256SUMS + signature
  Media->>Proxmox: Transfer bundle
  Proxmox->>Proxmox: Verify SHA256 & cosign
  Proxmox->>LXC1: Create LXC via Helper-Scripts installer
  Proxmox->>LXC2: Create LXC via Helper-Scripts installer
  LXC1->>LXC1: Install k3s (stable)
  LXC1->>LXC1: Apply Argo CD manifests
  LXC2->>LXC2: Start Gitea (systemd)
  LXC1->>LXC2: GitOps sync from Gitea
```
