
# PRD (Product Requirement Document)
Author:Your Name Here
---
## Background
Set the context for your product...
---
(Template content abbreviated here for brevity in the generated bundle. Use the full template during authoring.)
