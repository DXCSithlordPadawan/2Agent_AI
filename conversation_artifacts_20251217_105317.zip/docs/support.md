
# Support & Runbooks

Generated: 2025-12-17 10:53:17 UTC

- Argo CD: `argocd login <server>`; see operator manual. [Docs](https://argo-cd.readthedocs.io/en/stable/)
- k3s: `systemctl status k3s`; logs via `journalctl`. [Quick start](https://documentation.suse.com/cloudnative/k3s/latest/en/quick-start.html)
- Gitea: `systemctl status gitea`; config `/etc/gitea/app.ini`. [Linux service docs](https://docs.gitea.com/installation/linux-service)
