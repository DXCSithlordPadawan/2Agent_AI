
# TOGAF Views & Viewpoints

Generated: 2025-12-17 10:53:17 UTC

## Mermaid: Stakeholders, Viewpoints, and Views
```mermaid
flowchart TB
  subgraph Stakeholders
    PE[Platform Engineering]
    TR[Trainers/Authors]
    OP[Operations]
  end
  subgraph Viewpoints
    BV[Business]
    AV[Application]
    TV[Technology]
    DV[Data]
  end
  subgraph Views
    CapMap[Capability Map]
    GitOps[GitOps App/Project Topology]
    Infra[Proxmox/LXC/Network]
    Artefacts[Repos/SBOM/Signatures]
  end
  PE --> TV
  TR --> BV
  OP --> DV
  BV --> CapMap
  AV --> GitOps
  TV --> Infra
  DV --> Artefacts
```

References: [TOGAF Library](https://www.opengroup.org/togaf%C2%AE-library)
