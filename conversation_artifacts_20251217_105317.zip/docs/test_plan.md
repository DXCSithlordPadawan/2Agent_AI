
# Test Plan

Generated: 2025-12-17 10:53:17 UTC

## Mermaid: Health & Validation Flow
```mermaid
flowchart LR
  CreateLXC[Create LXC] --> K3sReady[k3s Node Ready]
  K3sReady --> ArgoReady[Argo CD Server Ready]
  ArgoReady --> Sync[Argo CD Sync from Gitea]
  Sync --> Success[Apps Healthy]
  Sync -->|Fail| Investigate[Investigate & Rollback]
```
