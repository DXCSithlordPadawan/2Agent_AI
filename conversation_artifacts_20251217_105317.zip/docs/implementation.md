
# Implementation Guide

Generated: 2025-12-17 10:53:17 UTC

## External Pi (Raspberry Pi OS Trixie)
- Download **Argo CD CLI (arm64)** `v3.2.1`; verify checksum/signature. [CLI install](https://argo-cd.readthedocs.io/en/stable/cli_installation/)
- Mirror images to `registry.internal:5000` and build signed bundle.

## Proxmox VE 9.1 Cluster
- Run **Helper‑Scripts‑style** installers:
  - `/ct/argocd-k3s-install.sh` (Debian 13 LXC; k3s + Argo CD)
  - `/ct/gitea-install.sh` (Debian 13 LXC; Gitea)

## Mermaid: Packaging & Deployment Sequence
```mermaid
sequenceDiagram
  autonumber
  participant Pi
  participant Reg as Local Registry
  participant USB as USB/SSD
  participant PVE as Proxmox 9.1
  participant LXCk3s as LXC argocd-k3s
  participant LXCGit as LXC gitea
  Pi->>Reg: Push mirrored images
  Pi->>Pi: Build bundle + SBOM + SHA256 + cosign
  Pi->>USB: Write bundle
  USB->>PVE: Transfer
  PVE->>PVE: Verify signatures & checksums
  PVE->>LXCk3s: Run argocd-k3s installer
  PVE->>LXCGit: Run gitea installer
  LXCk3s->>LXCGit: Configure repo paths & sync
```
