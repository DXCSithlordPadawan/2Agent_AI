
# Versions (Generation-Time)

Generated: 2025-12-17 10:53:17 UTC

- Argo CD: v3.2.1 (latest stable as of 2025‑11‑30).
- k3s: stable channel (record exact version at install).
- Gitea: latest (record exact version at install).
