
# Maintenance Tasks

Generated: 2025-12-17 10:53:17 UTC

- Patch cadence: monthly (OS), quarterly (k3s/Argo CD). [Argo CD releases](https://github.com/argoproj/argo-cd/releases)
- Re‑mirror cadence: per upstream release; update digests.
- Cert rotation: refresh trust stores and registry certs.
- SBOM refresh: regenerate `/package/SBOM/sbom.json` when bundle changes.
