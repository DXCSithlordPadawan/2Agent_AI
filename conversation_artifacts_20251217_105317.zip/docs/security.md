
# Security Constraints & Compliance Mapping

Generated: 2025-12-17 10:53:17 UTC

## Baselines
- **CIS Kubernetes Benchmark – Level 2** (stronger controls; may reduce functionality). [CIS Benchmarks](https://www.cisecurity.org/benchmark/kubernetes)
- **DISA STIG – Kubernetes** (control-plane & node hardening). [STIG Viewer](https://www.stigviewer.com/stigs/kubernetes)
- **FIPS 140‑3** – cryptographic module requirements & guidance. [FIPS 140‑3](https://csrc.nist.gov/pubs/fips/140-3/final)

## Mermaid: Baselines to Controls Mapping
```mermaid
flowchart TB
  subgraph Baselines
    CIS[CIS K8s L2]
    STIG[DISA STIG K8s]
    FIPS[FIPS 140-3]
  end
  subgraph Controls
    Authz[RBAC & AuthN]
    PSA[Pod Security Admission]
    Audit[Audit & Logging]
    Images[Signed Images & Registry]
    Crypto[Approved Crypto Modules]
  end
  CIS --> PSA
  CIS --> Audit
  STIG --> Authz
  STIG --> Audit
  FIPS --> Crypto
  Images --> PSA
```
