
# Air‑Gap Transfer & Verification

Generated: 2025-12-17 10:53:17 UTC

1) Copy `airgap-bundle-YYYYMMDD.tar.gz` to USB/SSD.
2) Verify checksums: `sha256sum -c package/checksums/SHA256SUMS`.
3) Verify signature with **cosign**. [Cosign verify](https://docs.sigstore.dev/cosign/verifying/verify/)
4) Extract & run installers: `ct/argocd-k3s-install.sh`, `ct/gitea-install.sh`.
