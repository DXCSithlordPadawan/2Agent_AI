
# Assumptions & Defaults

Generated: 2025-12-17 10:53:17 UTC

- Proxmox VE version: **9.1** (features include OCI-based LXC templates and improved TPM state handling). [Proxmox press release](https://www.proxmox.com/en/about/company-details/press-releases/proxmox-virtual-environment-9-1), [4sysops overview](https://4sysops.com/archives/proxmox-ve-91-create-lxc-containers-from-oci-images-granular-nested-virt-cpu-control-and-more/)
- Proxmox storage (default): **local-lvm**
- Proxmox bridge (default): **vmbr0**
- LXC base OS: **Debian 13 “Trixie”** (Raspberry Pi OS rebased on Debian 13). [Raspberry Pi blog](https://www.raspberrypi.com/news/trixie-the-new-version-of-raspberry-pi-os/)
- Kubernetes distro: **k3s** (installed via get.k3s.io; supports air‑gap images tar and `registries.yaml`). [K3s quick start](https://documentation.suse.com/cloudnative/k3s/latest/en/quick-start.html), [Air-gap install](https://ranchermanager.docs.rancher.com/getting-started/installation-and-upgrade/other-installation-methods/air-gapped-helm-cli-install/install-kubernetes)
- Argo CD version: **v3.2.1** (latest stable as of 2025‑11‑30). [Release listing](https://releasealert.dev/github/argoproj/argo-cd)
- Internal Git server: **Gitea** (systemd service). [Gitea service sample](https://github.com/go-gitea/gitea/blob/main/contrib/systemd/gitea.service), [Gitea Linux service docs](https://docs.gitea.com/installation/linux-service)
- Internal DNS & CA: cluster-local; CA PEMs provided by operator.
- Local registry: `registry.internal:5000` (TLS using internal CA).
- Security posture: **CIS Kubernetes Level 2**, **DISA STIG Kubernetes**, **FIPS 140‑3**. [CIS Benchmarks](https://www.cisecurity.org/benchmark/kubernetes), [STIG](https://www.stigviewer.com/stigs/kubernetes), [FIPS 140‑3](https://csrc.nist.gov/pubs/fips/140-3/final)
- Transfer medium: **USB/SSD** with **SHA256** and **cosign** signatures. [Cosign verify](https://docs.sigstore.dev/cosign/verifying/verify/)

**Diagram format:** All diagrams in this bundle are **Mermaid**.
