#!/usr/bin/env bash
argocd app list
