#!/usr/bin/env bash
pct list
