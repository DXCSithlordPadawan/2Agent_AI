#!/usr/bin/env bash
kubectl get nodes
