#!/usr/bin/env bash
kubectl get nodes -o wide
kubectl get pods -A
