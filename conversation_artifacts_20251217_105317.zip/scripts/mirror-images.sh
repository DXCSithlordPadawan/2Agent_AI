
#!/usr/bin/env bash
set -euo pipefail
REGISTRY="registry.internal:5000"
IMAGES=("quay.io/argoproj/argocd:v3.2.1")
for img in "${IMAGES[@]}"; do
  dst="${REGISTRY}/$(echo "$img" | sed 's#^[^/]*/##')"
  echo "Mirror $img -> $dst"
  # skopeo copy docker://"$img" docker://"$dst"
done
