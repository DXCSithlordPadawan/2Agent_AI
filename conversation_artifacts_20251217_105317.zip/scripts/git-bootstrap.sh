#!/usr/bin/env bash
# TODO: seed repos in Gitea via API
