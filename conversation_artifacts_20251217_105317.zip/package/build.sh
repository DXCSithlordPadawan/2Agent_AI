
#!/usr/bin/env bash
set -euo pipefail
OUT="airgap-bundle-$(date +%Y%m%d).tar.gz"
mkdir -p package/checksums package/SBOM
 tar -czf "$OUT" docs deploy scripts tests ct package/SBOM assumptions.md
sha256sum "$OUT" > package/checksums/SHA256SUMS
# cosign sign-blob --key package/cosign.key --output-signature "$OUT.sig" "$OUT"
echo "Bundle: $OUT"
