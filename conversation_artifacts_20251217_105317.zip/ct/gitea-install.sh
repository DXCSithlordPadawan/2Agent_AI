#!/usr/bin/env bash
echo Create LXC gitea with local-lvm/vmbr0 and install Gitea
