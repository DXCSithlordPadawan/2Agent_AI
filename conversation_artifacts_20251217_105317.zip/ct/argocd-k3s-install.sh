#!/usr/bin/env bash
echo Create LXC argocd-k3s with local-lvm/vmbr0 and install k3s + Argo CD
